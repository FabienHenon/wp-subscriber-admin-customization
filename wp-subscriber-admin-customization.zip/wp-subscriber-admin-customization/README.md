# wp-subscriber-admin-customization

This plugin will:

- Change admin color
- Redirect subscribers to a custom page
- Simplify the subscriber's profile

